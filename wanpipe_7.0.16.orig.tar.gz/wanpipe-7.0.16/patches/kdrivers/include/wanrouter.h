
/* Deprecated file header. Here for the sake of backward compatibility */

#ifdef __LINUX__
#warning "Using DEPRECATED headre wanrouter.h -> change to wanpipe_wanrouter.h"
#endif
#include "wanpipe_wanrouter.h"

