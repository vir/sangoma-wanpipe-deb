/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File: octtypentdrv.h

Description:	File is not used and kept only for backward compatibility.

Author:

Version:

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCTTYPENTDRV_H__
#define __OCTTYPENTDRV_H__

#if defined(__KERNEL__)
#endif	/*__KERNEL__*/
#endif	/*__OCTTYPENTDRV_H__*/
