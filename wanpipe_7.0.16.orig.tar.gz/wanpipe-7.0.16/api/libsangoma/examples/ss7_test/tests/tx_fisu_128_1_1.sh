#!/bin/sh

cd ..
./tdm_hdlc_test.sh "1" 1 0 "-verbose 3 -tx_delay 100000  "
