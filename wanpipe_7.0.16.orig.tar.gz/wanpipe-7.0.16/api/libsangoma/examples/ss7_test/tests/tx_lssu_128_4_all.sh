#!/bin/sh

cd ..
./tdm_hdlc_test.sh "1 2 3 4" all 10 "-ss7_mode_128 -ss7_lssu_sz 4 -tx_lssu"

