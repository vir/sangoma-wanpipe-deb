#!/bin/sh

cd ..
./tdm_hdlc_test.sh "1" 1 0 "-verbose 3 -tx_delay 4000000 -ss7_mode_128 -ss7_lssu_sz 4 -tx_lssu"

