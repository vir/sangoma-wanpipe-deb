#!/bin/sh
./tdm_hdlc_test.sh "1" 1 0 "-verbose 3 -tx_delay 100000 -ss7_mode_4096 "
