
g3ti_api.exe -
Integration of Sangoma API into C++ classes designed
by G3TI (http://www.g3ti.net/)



Linux Installation
------------------


1. Download Latest Linux Relelase
	-> wiki.sangoma.com

2. Untar linux release and change directory
	-> tar xfz wanpipe-<ver>.tgz
	-> cd wanpipe-<ver>

3. Build wanpipe release Change directory into wanpipe-<ver>
	-> make g3ti
	-> make install

4. Confirm that wanpipe drivers installed properly
  	-> wanrouter hwprobe
	
	
5. Build g3ti_api_libsangoma_<ver> applicatoin


