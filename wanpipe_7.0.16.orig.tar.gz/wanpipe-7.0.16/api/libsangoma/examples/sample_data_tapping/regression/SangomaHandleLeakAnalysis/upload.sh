#!/bin/sh

sangoma_ftp.pl $1 linux/custom/g3ti
sangoma_ftp.pl ChangeLog linux/custom/g3ti
