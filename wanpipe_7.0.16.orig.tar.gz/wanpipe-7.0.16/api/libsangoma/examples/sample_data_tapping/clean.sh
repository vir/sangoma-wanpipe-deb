#!/bin/sh

rm -f *.log
rm -f *.*~ 
