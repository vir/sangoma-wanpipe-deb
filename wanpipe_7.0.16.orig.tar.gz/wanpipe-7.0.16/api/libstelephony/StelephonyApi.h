
/* This is a deprecated include file. 
   You should be using the new API include file  libstelephony.h */

#include "libstelephony.h"
