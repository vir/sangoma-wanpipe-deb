#!/bin/sh

./sangoma_mgd_unit -term
sangoma_mgd -term

