#!/bin/sh

cd ./scripts/callgen

nice ./run.sh > /dev/null &

echo "Test Started"
