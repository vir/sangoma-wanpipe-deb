
#ifndef __SMG_COMMON_H_
#define __SMG_COMMON_H_


#define WOOMERA_MAX_SPAN	32
#define WOOMERA_MAX_CHAN	31

#define WOOMERA_BRI_MAX_SPAN	32
#define WOOMERA_BRI_MAX_CHAN	2

extern int max_spans;
extern int max_chans;


#endif
