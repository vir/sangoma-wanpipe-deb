#!/bin/sh
exit -1
echo " " > /var/log/messages
echo " " > /var/log/woomerang.log
echo " " > /var/log/sangoma_mgd.log
echo " " > /var/log/asterisk/messages

echo "Logs Clear"

